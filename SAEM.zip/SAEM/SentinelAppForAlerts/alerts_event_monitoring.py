"""All the API related operations are performed here."""
import os
import logging
import requests
import json
from . import constants
from .state_manager import StateManager
from .AzureSentinel import AzureSentinel
from . import utils


class HttpManager:
    """Handles the http  requests."""

    def __init__(self, link, api_key="") -> None:
        """Initialize the link and Api key.

        Args:
            link (str): The link to query
            api_key (str, optional): The authorization token. Defaults to "".
        """
        self.link = link
        self.api_key = api_key

    def get_request(self, link_embedded_parameters="", parameters=""):
        """Perform get request and returns the http response object.

        Args:
            link_embedded_parameters (str, optional):Data that you want to embed to the link.
            Defaults to "".
            parameters (str, optional): get request parameters if any. Defaults to "".

        Returns:
            response_object: The response object of the http request
        """
        try:
            logging.info(
                "Alerts Event Monitoring Data Connector:Initiating get request"
            )
            session_object = requests.session()
            link_to_hit = self.link + link_embedded_parameters
            response_object = session_object.get(
                link_to_hit, params=parameters, headers={"Authorization": self.api_key}
            )
            logging.info(
                "Alerts Event Monitoring Data Connector:GET request performed successfully"
            )
            return response_object

        except requests.exceptions.ConnectionError as connect_error:
            logging.info(
                "Alerts Event Monitoring Data Connector: {}".format(connect_error)
            )
        except requests.exceptions.InvalidURL as invalid_url_error:
            logging.info(
                "Alerts Event Monitoring Data Connector: {}".format(invalid_url_error)
            )
        except TimeoutError as exception:
            logging.info("Alerts Event Monitoring Data Connector: {}".format(exception))
        except Exception as exception:
            logging.info("Alerts Event Monitoring Data Connector: {}".format(exception))

    def post_request(self, link_embedded_parameters="", parameters="", body=""):
        """Perform Post Request and return the http response object.

        Args:
            link_embedded_parameters (str, optional):Data that you want to embed to the link.
            Defaults to "".
            parameters (str, optional): Post Request parameters if any. Defaults to "".

        Returns:
            response_object: The response object of the http request
        """
        try:
            logging.info(
                "Alerts Event Monitoring Data Connector:Initiating Post Request"
            )
            session_object = requests.session()
            link_to_hit = self.link + link_embedded_parameters
            response_object = session_object.post(
                link_to_hit,
                params=parameters,
                headers={"Authorization": self.api_key},
                data=body,
            )
            logging.info(
                "Alerts Event Monitoring Data Connector:Post Request performed successfully"
            )
            return response_object

        except requests.exceptions.ConnectionError as connect_error:
            logging.info(
                "Alerts Event Monitoring Data Connector: {}".format(connect_error)
            )
        except requests.exceptions.InvalidURL as invalid_url_error:
            logging.info(
                "Alerts Event Monitoring Data Connector: {}".format(invalid_url_error)
            )
        except TimeoutError as exception:
            logging.info("Alerts Event Monitoring Data Connector: {}".format(exception))
        except Exception as exception:
            logging.info("Alerts Event Monitoring Data Connector: {}".format(exception))


class AlertsEventMonitoring:
    """Handles the operations related to the API."""

    def __init__(self) -> None:
        """Init function to initialize the variables."""
        self.client_secret = os.environ.get("CLIENT_SECRET")
        self.client_id = os.environ.get("CLIENT_ID")
        self.connection_string = os.environ.get("CONN_STRING")
        self.token_file_name = "token"
        self.checkpoint_file_name = "checkpoint"
        self.alerts_table_name = os.environ.get("Alerts_Table_Name")
        self.related_alerts_table_name = os.environ.get("Related_Alerts_Table_Name")
        self.token_state_manager_object = StateManager(
            self.connection_string, self.token_file_name
        )
        self.token = self.token_state_manager_object.get()
        logging.info(
            "Alerts Event Monitoring Data Connector: Token Fetched from File Share"
        )
        logging.info(
            "Alerts Event Monitoring Data Connector: Token Fetched from File Share"
        )
        if self.token is None:
            logging.info(
                "Alerts Event Monitoring Data Connector: Token not present in File Share,Generating new Token"
            )
            self.generate_api_token()
            if self.token is None:
                logging.error(
                    "Alerts Event Monitoring Data Connector: Authentication Error in Generating Token"
                )
            else:
                logging.info(
                    "Alerts Event Monitoring Data Connector: Fetched New Token"
                )
        logging.info(self.token)

    def generate_api_token(self):
        """Generate API TOKEN.

        Returns:
            API_TOKEN: Api token for authentication
        """
        try:
            link = constants.BASE_URL + constants.GET_TOKEN_ENDPOINT
            http_manager_object = utils.HttpManager(link=link)
            response = http_manager_object.perform_request(
                type_of_request="POST",
                body={
                    "grant_type": "api_key",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                },
            )
            if response.status_code == 200:
                logging.info(response.json())
                self.token = "Dmauth {}".format(response.json()["dmaToken"])
                self.token_state_manager_object.post(self.token)
            if response.status_code == 401:
                logging.error(
                    "Alerts Event Monitoring Data Connector: Client Id and Client Secret are Incorrect. "
                )
            if response.status_code == 500:
                logging.error(
                    "Alerts Event Monitoring Data Connector: Internal Server Error. "
                )

        except KeyError as key_error:
            logging.error(
                "Alerts Event Monitoring Data Connector: There has been an Error in Generating API token,\
                Token not returned. {}".format(
                    key_error
                ),
            )
        except Exception as error:
            logging.error(
                "Alerts Event Monitoring Data Connector: Error in the code {}".format(
                    error
                )
            )

    def get_ids_from_watchlist(self, response_json):
        """Parse the json response and return the list of watchlist ids.

        Args:
            response_json (json): Json Response from the API

        Returns:
            dict: Dictionary containing All ids.
        """
        try:
            company_list = response_json["watchlists"]["COMPANY"]
            custom_list = response_json["watchlists"]["CUSTOM"]
            topic_list = response_json["watchlists"]["TOPIC"]
            all_ids = []
            company_list_ids = []
            custom_list_ids = []
            topic_list_ids = []
            ids_dict = {}
            for i in topic_list:
                topic_list_ids.append(i["id"])
                all_ids.append(i["id"])
            for i in custom_list:
                custom_list_ids.append(i["id"])
                all_ids.append(i["id"])
            for i in company_list:
                company_list_ids.append(i["id"])
                all_ids.append(i["id"])
            ids_dict["company_ids"] = company_list_ids
            ids_dict["custom_ids"] = custom_list_ids
            ids_dict["topic_ids"] = topic_list_ids
            ids_dict["all_ids"] = all_ids
            logging.info(ids_dict["all_ids"])
            return ids_dict
        except KeyError as key_error:
            logging.error(
                "Alerts Event Monitoring Data Connector: Key not present in watchlist Response. Error:{}".format(
                    key_error
                )
            )

    def get_lists(self):
        """Get watchlist data from the API.

        Returns:
            dict: list containing all the watchlist ids.
        """
        try:
            http_manager_object = HttpManager(
                constants.BASE_URL + constants.GET_LISTS_ENDPOINT, api_key=self.token
            )
            response = http_manager_object.get_request()
            if response.status_code == 401 or response.status_code == 500:
                logging.error("Token Expired")
                logging.info("Generating Token again")
                self.generate_api_token()
                http_manager_object = HttpManager(
                    constants.BASE_URL + constants.GET_LISTS_ENDPOINT,
                    api_key=self.token,
                )
                response = http_manager_object.get_request()
            response_json = response.json()
            watchlist_ids = self.get_ids_from_watchlist(response_json)
            return watchlist_ids
            # print(response.json())
        except Exception as error:
            logging.error("Alerts Event Monitoring Data Connector: {}".format(error))
            print(error)

    def perform_request(self, link, parameters):
        httpmanager_object = HttpManager(link=link, api_key=self.token)
        response = httpmanager_object.get_request(parameters=parameters)
        if response.status_code == 401 or response.status_code == 500:
            logging.error("Token Expired")
            logging.info("Generating Token again")
            self.generate_api_token()
            self.perform_request(link, parameters)
        if response.status_code == 200:
            return response

    def get_related_alerts(self, data: list):
        """Get Related Alerts Data from alerts data

        Args:
            data (list): Alerts Data
        """
        try:
            link = constants.BASE_URL + constants.GET_RELATED_ALERTS_ENDPOINT
            azure_sentinel_object = AzureSentinel()
            for i in data:
                if i["availableRelatedAlerts"] > 0:
                    response = self.perform_request(
                        link, {"alertversion": "14", "id": i["alertId"]}
                    )
                    response_json = response.json()
                    logging.info(
                        "Alerts Event Monitoring: Related Alerts Length: {}".format(
                            len(response_json)
                        )
                    )
                    if len(response_json) > 0:
                        status_code = azure_sentinel_object.post_data(
                            json.dumps(response_json), self.related_alerts_table_name
                        )
                        logging.info(
                            "Alerts Event Monitoring:The status code returned is {}".format(
                                status_code
                            )
                        )

                        logging.info(
                            "Alerts Event Monitoring: Ingested Related Alerts Data for alert id - {}".format(
                                i["alertId"]
                            )
                        )
                    else:
                        logging.info(
                            "Alerts Event Monitoring: No related alerts present"
                        )
                        # self.common_operations_object.write_to_json_file('related_alerts.json',response_json)
                        # self.common_operations_object.ingest_data_to_sentinel(response_json,'RelatedAlertsTableName'
        except Exception as error:
            logging.error("Error has occured in Related Alerts %s", error)

    def get_alerts(self):
        """Get alerts from alerts API"""
        try:
            azure_sentinel_object = AzureSentinel()
            state_manager_object = StateManager(
                self.connection_string, self.checkpoint_file_name
            )
            checkpoint_data = state_manager_object.get()
            link = constants.BASE_URL + constants.GET_ALERTS_ENDPOINT
            watchlist_ids = self.get_lists()
            if checkpoint_data is None:
                params = {"alertversion": 14, "lists": watchlist_ids["all_ids"]}
            else:
                params = {
                    "alertversion": 14,
                    "lists": watchlist_ids["all_ids"],
                    "from": checkpoint_data,
                }
            response = self.perform_request(link, params)
            json_response = response.json()
            alerts_data = json_response["data"]["alerts"]
            self.get_related_alerts(json_response["data"]["alerts"])
            # ingest data to sentinel
            logging.info(
                "Alerts Event Monitoring: Length of alerts is {}".format(
                    len(alerts_data)
                )
            )
            status_code = azure_sentinel_object.post_data(
                body=json.dumps(alerts_data), log_type=self.alerts_table_name
            )
            logging.info(
                "Alerts Event Monitoring:The status code returned is {}".format(
                    status_code
                )
            )

            state_manager_object.post(json_response["data"]["to"])
            while json_response["data"]["from"] != json_response["data"]["to"]:
                response = self.perform_request(
                    link,
                    {
                        "alertversion": 14,
                        "lists": watchlist_ids["all_ids"],
                        "from": json_response["data"]["to"],
                    },
                )
                json_response = response.json()
                alerts_data = json_response["data"]["alerts"]
                self.get_related_alerts(alerts_data)
                # ingest data to sentinel
                logging.info(
                    "Alerts Event Monitoring: Length of alerts is {}".format(
                        len(alerts_data)
                    )
                )
                status_code = azure_sentinel_object.post_data(
                    body=json.dumps(alerts_data), log_type=self.alerts_table_name
                )
                logging.info(
                    "Alerts Event Monitoring:The status code returned is {}".format(
                        status_code
                    )
                )

                state_manager_object.post(json_response["data"]["to"])

        except Exception as error:
            logging.error("Alerts Event Monitoring Data Connector: {}".format(error))
