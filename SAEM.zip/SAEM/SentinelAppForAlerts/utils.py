"""Utills Module for Common Operations"""
import logging
import requests


class HttpManager:
    """Handles the http  requests."""

    def __init__(self, link, api_key="") -> None:
        """Initialize the link and Api key.

        Args:
            link (str): The link to query
            api_key (str, optional): The authorization token. Defaults to "".
        """
        self.link = link
        self.api_key = api_key

    def perform_request(
        self, type_of_request, link_embedded_parameters="", parameters="", body=""
    ):
        """Perform the Request and return the response.

        Args:
            type_of_request (str): Type of Request(GET/POST)
            link_embedded_parameters (str, optional):Data that you want to embed to the link.
            parameters (str, optional): get request parameters if any. Defaults to "".
            body (dict, optional): Post Request Body. Defaults to "".
        """
        try:
            session_object = requests.session()
            link_to_hit = self.link + link_embedded_parameters
            if type_of_request.upper() == "GET":
                logging.info(
                    "Alerts Event Monitoring Data Connector:Initiating GET request"
                )
                response_object = session_object.get(
                    link_to_hit,
                    params=parameters,
                    headers={"Authorization": self.api_key},
                )
            elif type_of_request.upper() == "POST":
                logging.info(
                    "Alerts Event Monitoring Data Connector:Initiating POST request"
                )
                response_object = session_object.post(
                    link_to_hit,
                    params=parameters,
                    headers={"Authorization": self.api_key},
                    data=body,
                )
            else:
                logging.error(
                    "HTTP Manager Error: Wrong Type of Request Passed. Valid options are get/post"
                )
                return None

            logging.info(
                "Alerts Event Monitoring Data Connector:Request performed successfully"
            )
            return response_object

        except requests.exceptions.ConnectionError as connect_error:
            logging.error(
                "Alerts Event Monitoring Data Connector: {}".format(connect_error)
            )
        except requests.exceptions.InvalidURL as invalid_url_error:
            logging.error(
                "Alerts Event Monitoring Data Connector: {}".format(invalid_url_error)
            )
        except TimeoutError as exception:
            logging.error(
                "Alerts Event Monitoring Data Connector: {}".format(exception)
            )
        except Exception as exception:
            logging.error(
                "Alerts Event Monitoring Data Connector: {}".format(exception)
            )
