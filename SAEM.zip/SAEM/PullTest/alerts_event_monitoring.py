"""All the API related operations are performed here."""
import os
import logging
import json
import inspect
from . import constants
from .utils import HttpManager
from .utils import CommonOperations
from .AzureSentinel import AzureSentinel
from .AlertsEventMonitoringExceptions import AlertsEventMonitoringException


class AlertsEventMonitoring:
    """Handles the operations related to the API."""

    def __init__(self) -> None:
        """Init function to initialize the variables."""
        self.common_operations_object = CommonOperations()
        self.token = ""

    def generate_api_token(self):
        """Generate API TOKEN and store it in checkpoint file.

        Raises:
            AlertsEventMonitoringException: Raises Exception if execution fails.
        """
        try:
            func_name = inspect.currentframe().f_code.co_name
            client_secret = os.environ.get("CLIENT_SECRET", "")
            client_id = os.environ.get("CLIENT_ID", "")
            if client_id == "":
                logging.error(
                    "{}(method_name={}): Client Id not present.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                raise AlertsEventMonitoringException()
            if client_secret == "":
                logging.error(
                    "{}(method_name={}): Client Secret not present.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                raise AlertsEventMonitoringException()
            link = constants.BASE_URL + constants.GET_TOKEN_ENDPOINT
            http_manager_object = HttpManager(link=link)
            response = http_manager_object.perform_http_request(
                type_of_request="POST",
                body={
                    "grant_type": "api_key",
                    "client_id": client_id,
                    "client_secret": client_secret,
                },
            )
            if response.status_code == 200:
                json_response = response.json()
                dma_token = json_response.get("dmaToken", "")
                if dma_token == "":
                    logging.error(
                        "{}(method_name={}): Token Not present in API response.".format(
                            constants.LOGS_PREFIX, func_name
                        )
                    )
                    raise AlertsEventMonitoringException()
                self.token = "Dmauth {}".format(dma_token)
                self.common_operations_object.post_data_to_checkpoint(
                    "token", self.token
                )
            elif response.status_code == 500:
                logging.error(
                    "{}(method_name={}): Internal Server Error while Authenticating".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                raise AlertsEventMonitoringException()
            elif response.status_code == 400:
                logging.error(
                    "{}(method_name={}): Bad Request, The format of the request is incorrect".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                raise AlertsEventMonitoringException()
            elif response.status_code == 401:
                logging.error(
                    "{}(method_name={}): Client Id or Client Secret are Incorrect/Not Provided.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                raise AlertsEventMonitoringException()
            elif response.status_code == 404:
                logging.error(
                    "{}(method_name={}): URL not found.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                raise AlertsEventMonitoringException()
            else:
                logging.error(
                    "{}(method_name={}): Unknown Error, Response Status Code-{}".format(
                        constants.LOGS_PREFIX, func_name, response.status_code
                    )
                )
                raise AlertsEventMonitoringException()
        except AlertsEventMonitoringException:
            logging.error(
                "{}(method_name={}): Generating API Token failed.".format(
                    constants.LOGS_PREFIX, func_name
                )
            )
            raise AlertsEventMonitoringException()

    def authenticate(self):
        """Check stored auth token and generate new token if necessary."""
        func_name = inspect.currentframe().f_code.co_name
        try:
            self.token = self.common_operations_object.get_checkpoint_data("token")
            if self.token is None or self.token == "":
                logging.info(
                    "{}(method_name={}): Token not present in File Share,Generating new Token.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                self.generate_api_token()
                logging.info(
                    "{}(method_name={}): Fetched New Token.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
            else:
                logging.info(
                    "{}(method_name={}): Token Fetched from File Share.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
        except AlertsEventMonitoringException:
            logging.error(
                "{}(method_name={}): Error in Authentication.".format(
                    constants.LOGS_PREFIX, func_name
                )
            )
            raise AlertsEventMonitoringException()
        except Exception as error:
            logging.error(
                "{}(method_name={}): Authentication failed: {}.".format(
                    constants.LOGS_PREFIX, func_name, error
                )
            )
            raise AlertsEventMonitoringException()

    def get_ids_from_watchlist(self, response_json):
        """Parse the json response and return the list of watchlist ids.

        Args:
            response_json (json): Json Response from the API

        Returns:
            list: List containing All ids.
        """
        func_name = inspect.currentframe().f_code.co_name
        try:
            watchlists_names = list(response_json["watchlists"].keys())
            all_ids = []
            for i in watchlists_names:
                all_ids.extend([x["id"] for x in response_json["watchlists"][i]])
            logging.info(
                "{}(method_name={}): {}.".format(
                    constants.LOGS_PREFIX, func_name, all_ids
                )
            )
            return all_ids
        except KeyError as key_error:
            logging.error(
                "{}(method_name={}): Key not present in watchlist Response, Error:{}.".format(
                    constants.LOGS_PREFIX, func_name, key_error
                )
            )
            raise AlertsEventMonitoringException()

    def get_lists(self):
        """Get watchlist data from the API.

        Returns:
            list: list containing all the watchlist ids.
        """
        func_name = inspect.currentframe().f_code.co_name
        try:
            link = constants.BASE_URL + constants.GET_LISTS_ENDPOINT
            response = self.request_using_retry_mechanism(link=link, parameters="")
            return self.get_ids_from_watchlist(response_json=response.json())
        except AlertsEventMonitoringException:
            logging.error(
                "{}(method_name={}): Fetching Lists Failed".format(
                    constants.LOGS_PREFIX, func_name
                )
            )
            raise AlertsEventMonitoringException()
        except Exception as error:
            logging.error(
                "{}(method_name={}): Fetching Lists Failed-{}".format(
                    constants.LOGS_PREFIX, func_name, error
                )
            )
            raise AlertsEventMonitoringException()

    def request_using_retry_mechanism(self, link, parameters):
        """Request Function for API  requests with retry Mechanism.

        Args:
            link (str): Link to query
            parameters (dict): parameters to pass to the get request

        Returns:
            response object: Response returned from the Get request call
        """
        func_name = inspect.currentframe().f_code.co_name
        try:
            retry = 0
            while retry <= 2:
                http_manager_object = HttpManager(link=link, api_key=self.token)
                response = http_manager_object.perform_http_request(
                    type_of_request="GET", parameters=parameters
                )
                if response.status_code == 200:
                    return response
                if response.status_code in (401, 500):
                    logging.error(
                        "{}(method_name={}): Error 401/500.".format(
                            constants.LOGS_PREFIX, func_name
                        )
                    )
                    logging.info(
                        "{}(method_name={}): Retrying by Generating Token again.".format(
                            constants.LOGS_PREFIX, func_name
                        )
                    )
                    self.generate_api_token()
                    retry += 1
                elif response.status_code == 404:
                    logging.error(
                        "{}(method_name={}): URL not found.".format(
                            constants.LOGS_PREFIX, func_name
                        )
                    )
                    raise AlertsEventMonitoringException()
                elif response.status_code == 429:
                    logging.error(
                        "{}(method_name={}): The API rate limit has been exceeded.".format(
                            constants.LOGS_PREFIX, func_name
                        )
                    )
                    raise AlertsEventMonitoringException()
                else:
                    logging.error(
                        "{}(method_name={}): Unknown Error, Status Code-{}".format(
                            constants.LOGS_PREFIX, func_name, response.status_code
                        )
                    )
                    raise AlertsEventMonitoringException()
            logging.error(
                "{}(method_name={}): Maximum Retries Exceeded from retry mechanism".format(
                    constants.LOGS_PREFIX, func_name
                )
            )
            raise AlertsEventMonitoringException()
        except AlertsEventMonitoringException:
            logging.error(
                "{}(method_name={}): Retry Mechanism Failed.".format(
                    constants.LOGS_PREFIX, func_name
                )
            )
            raise AlertsEventMonitoringException()
        except Exception as error:
            logging.error(
                "{}(method_name={}): Retry Mechanism Failed: {}".format(
                    constants.LOGS_PREFIX, func_name, error
                )
            )
            raise AlertsEventMonitoringException()

    def fetch_related_alerts_and_store_to_log_analytics(self, data: list):
        """Get Related Alerts Data from alerts data and ingest data to log analytics.

        Args:
            data (list): Alerts Data
        """
        func_name = inspect.currentframe().f_code.co_name
        try:
            link = constants.BASE_URL + constants.GET_RELATED_ALERTS_ENDPOINT
            azure_sentinel_object = AzureSentinel()
            related_alerts_table_name = os.environ.get("Related_Alerts_Table_Name")
            for i in data:
                if i["availableRelatedAlerts"] > 0:
                    response = self.request_using_retry_mechanism(
                        link, {"alertversion": "14", "id": i["alertId"]}
                    )
                    response_json = response.json()
                    if len(response_json) > 0:
                        azure_sentinel_object.post_data(
                            json.dumps(response_json), related_alerts_table_name
                        )
                        logging.info(
                            "{}(method_name={}): Ingested Related Alerts Data for alert id - {}.".format(
                                constants.LOGS_PREFIX, func_name, i["alertId"]
                            )
                        )
                    else:
                        logging.info(
                            "{}(method_name={}): No related alerts present for alert id - {}.".format(
                                constants.LOGS_PREFIX, func_name, i["alertId"]
                            )
                        )
        except AlertsEventMonitoringException as alerts_error:
            logging.error(
                "{}(method_name={}): Fetching Related Alerts Failed: {}.".format(
                    constants.LOGS_PREFIX, func_name, alerts_error
                )
            )
            raise AlertsEventMonitoringException()
        except KeyError as key_error:
            logging.error(
                "{}(method_name={}): Key Not present, Error-{}.".format(
                    constants.LOGS_PREFIX, func_name, key_error
                )
            )
            raise AlertsEventMonitoringException()
        except Exception as error:
            logging.error(
                "{}(method_name={}): {}.".format(
                    constants.LOGS_PREFIX, func_name, error
                )
            )
            raise AlertsEventMonitoringException()

    def fetch_alerts_and_store_to_log_analytics(self):
        """Get alerts from alerts API and ingest data to log analytics."""
        func_name = inspect.currentframe().f_code.co_name
        try:
            self.authenticate()
            watchlist_ids = self.get_lists()
            # Check if nothing is returned or empty array returned.
            alerts_table_name = os.environ.get("Alerts_Table_Name")
            azure_sentinel_object = AzureSentinel()
            checkpoint_data = self.common_operations_object.get_checkpoint_data(
                "checkpoint"
            )
            link = constants.BASE_URL + constants.GET_ALERTS_ENDPOINT
            if checkpoint_data is None or checkpoint_data == "":
                params = {"alertversion": 14, "lists": watchlist_ids}
            else:
                params = {
                    "alertversion": 14,
                    "lists": watchlist_ids,
                    "from": checkpoint_data,
                }
            response = self.request_using_retry_mechanism(link, params)
            json_response = response.json()
            alerts_data = json_response["data"]["alerts"]
            self.fetch_related_alerts_and_store_to_log_analytics(alerts_data)
            # ingest data to sentinel
            azure_sentinel_object.post_data(
                body=json.dumps(alerts_data), log_type=alerts_table_name
            )
            logging.info(
                "{}(method_name={}): Posted Data Successfully to Log Analytics.".format(
                    constants.LOGS_PREFIX, func_name
                )
            )
            self.common_operations_object.post_data_to_checkpoint(
                "checkpoint", json_response["data"]["to"]
            )
            while json_response["data"]["from"] != json_response["data"]["to"]:
                response = self.request_using_retry_mechanism(
                    link,
                    {
                        "alertversion": 14,
                        "lists": watchlist_ids,
                        "from": json_response["data"]["to"],
                    },
                )
                json_response = response.json()
                alerts_data = json_response["data"]["alerts"]

                self.fetch_related_alerts_and_store_to_log_analytics(alerts_data)
                # ingest data to sentinel
                azure_sentinel_object.post_data(
                    body=json.dumps(alerts_data), log_type=alerts_table_name
                )
                logging.info(
                    "{}(method_name={}): Posted Data Successfully to Log Analytics.".format(
                        constants.LOGS_PREFIX, func_name
                    )
                )
                self.common_operations_object.post_data_to_checkpoint(
                    "checkpoint", json_response["data"]["to"]
                )

        except KeyError as key_error:
            logging.error(
                "{}(method_name={}): Key Not present, Error-{}.".format(
                    constants.LOGS_PREFIX, func_name, key_error
                )
            )
            raise AlertsEventMonitoringException()
        except AlertsEventMonitoringException:
            logging.error(
                "{}(method_name={}): Error.".format(
                    constants.LOGS_PREFIX, func_name
                )
            )
            raise AlertsEventMonitoringException()
        except Exception as error:
            logging.error(
                "{}(method_name={}): Error-{}".format(
                    constants.LOGS_PREFIX, func_name, error
                )
            )
            raise AlertsEventMonitoringException()
