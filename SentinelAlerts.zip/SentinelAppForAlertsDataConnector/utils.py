"""Utills Module for Common Operations."""
import os
import logging
import requests
import json
from .state_manager import StateManager
from .AlertsEventMonitoringExceptions import AlertsEventMonitoringException


class HttpManager:
    """Handles the http  requests."""

    def __init__(self, link, api_key="") -> None:
        """Initialize the link and Api key.

        Args:
            link (str): The link to query
            api_key (str, optional): The authorization token. Defaults to "".
        """
        self.link = link
        self.api_key = api_key

    def perform_http_request(
        self, type_of_request, link_embedded_parameters="", parameters=None, body=None
    ):
        """Perform the Request and return the response.

        Args:
            type_of_request (str): Type of Request(GET/POST)
            link_embedded_parameters (str, optional):Data that you want to embed to the link.
            parameters (str, optional): get request parameters if any. Defaults to "".
            body (dict, optional): Post Request Body. Defaults to "".
        """
        try:
            session_object = requests.session()
            link_to_hit = self.link + link_embedded_parameters
            if type_of_request.upper() == "GET":
                logging.info("Alerts Event Monitoring:Initiating GET request.")
                response_object = session_object.get(
                    link_to_hit,
                    params=parameters,
                    headers={"Authorization": self.api_key},
                )
            else:
                logging.info("Alerts Event Monitoring:Initiating POST request.")
                response_object = session_object.post(
                    link_to_hit,
                    params=parameters,
                    headers={"Authorization": self.api_key},
                    data=body,
                )

            logging.info("Alerts Event Monitoring:Request performed successfully.")
            return response_object

        except requests.exceptions.ConnectionError as connect_error:
            logging.error("Alerts Event Monitoring: {}.".format(connect_error))
            raise AlertsEventMonitoringException()
        except requests.exceptions.InvalidURL as invalid_url_error:
            logging.error("Alerts Event Monitoring: {}.".format(invalid_url_error))
            raise AlertsEventMonitoringException()
        except TimeoutError as exception:
            logging.error("Alerts Event Monitoring: {}.".format(exception))
            raise AlertsEventMonitoringException()
        except Exception as exception:
            logging.error("Alerts Event Monitoring: {}.".format(exception))
            raise AlertsEventMonitoringException()


class CommonOperations:
    """Class containing the common operations."""

    def __init__(self) -> None:
        """Initiate connection string."""
        self.connection_string = os.environ.get("CONN_STRING")

    def get_checkpoint_data(self, key):
        """Get checkpoint data from azure file share.

        Args:
            key (str): The key to find in the checkpoint file.
        Returns:
            string: Checkpoint data
        """
        try:
            logging.info("Alerts Event Monitoring:Initiating the state manager object.")
            state_manager_object = StateManager(
                connection_string=self.connection_string, file_path="checkpoint"
            )
            logging.info("Alerts Event Monitoring:Getting the checkpoint file.")

            checkpoint_data = state_manager_object.get()
            if checkpoint_data is None or checkpoint_data == "":
                logging.info("Alerts Event Monitoring:No checkpoint data found")
                data_to_send = {key: ""}
                state_manager_object.post(json.dumps(data_to_send))
            else:
                check_point_json = json.loads(checkpoint_data)
                data = check_point_json[key]
                logging.info("Alerts Event Monitoring:Getting the file successfully.")
                logging.info(
                    "Alerts Event Monitoring:The Checkpoint data is {}".format(data)
                )
                return data

        except KeyError as key_error:
            logging.error(
                "The data is not present at the key {key} and error is {key_error}".format(
                    key=key, key_error=key_error
                )
            )
            raise AlertsEventMonitoringException()
        except Exception as error:
            logging.error("Alerts Event Monitoring: {}".format(error))
            raise AlertsEventMonitoringException()

    def post_data_to_checkpoint(self, key, value):
        """Post the checkpoint data to the Azure File share.

        Args:
            key (str): Key to store,
            value (str): Value of the key to store.
        """
        try:
            logging.info("Alerts Event Monitoring:Initiating the state manager object.")
            state_manager_object = StateManager(
                connection_string=self.connection_string, file_path="checkpoint"
            )
            checkpoint_data = state_manager_object.get()
            if checkpoint_data == "" or checkpoint_data is None:
                data_to_send = {key: value}
                logging.info(
                    "Alerts Event Monitoring:Posting the data to checkpoint file."
                )
                state_manager_object.post(json.dumps(data_to_send))
                logging.info("Alerts Event Monitoring:Posted the file successfully.")
            else:
                json_checkpoint = json.loads(checkpoint_data)
                json_checkpoint[key] = value
                logging.info(
                    "Alerts Event Monitoring:Posting the data to checkpoint file."
                )
                state_manager_object.post(json.dumps(json_checkpoint))
                logging.info("Alerts Event Monitoring:Posted the file successfully.")
        except Exception as error:
            logging.error("Alerts Event Monitoring: {}".format(error))
            raise AlertsEventMonitoringException()
