"""
Custom Exception Class
"""


class AlertsEventMonitoringException(Exception):
    """Exception class to handle AlertsEventMonitoring exception."""
